const About = () => {
    return (<>
        <h2>about</h2>
    </>);
}

export default About;