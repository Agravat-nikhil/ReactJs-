const Contact = () => {
    return (<>
        Contact
    </>);
}

export default Contact;